﻿#pragma once

class FBAToolbar_BlueprintImpl
{
public:
	static void DetectUnusedNodes();
};
